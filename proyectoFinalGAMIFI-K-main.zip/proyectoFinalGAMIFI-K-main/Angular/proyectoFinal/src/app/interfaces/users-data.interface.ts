export class UserData {
    
  constructor(
    public id: number,
    public nick: string,
    public name: string,
    public surnames: string,
    public email: string,
    public password: string,
    public img: string,
  ) { }
}
  