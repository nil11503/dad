export interface RankingData  {
    idUser: number;
    codeRanking: string;
    nombre: string;
    codigo_sala: string;
    
  }
  